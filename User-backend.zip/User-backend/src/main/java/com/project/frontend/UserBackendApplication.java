package com.project.frontend;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.project.frontend.dao.UserRepository;
import com.project.frontend.model.User;

@SpringBootApplication
public class UserBackendApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(UserBackendApplication.class, args);
	}

	@Autowired
	UserRepository userRepo;
	
	@Override
	public void run(String... args) throws Exception {
		
		userRepo.save(new User("Saranya", "Dillibabu", "saranyadillibabu1999@gmail.com"));
		userRepo.save(new User("Vini", "Vijay", "vinivijay132@gmail.com"));
		userRepo.save(new User("Sophia", "Williams", "sophiawilliams@gmail.com"));
		userRepo.save(new User("Sam", "John", "samjohn123@gmail.com"));
	}

}